<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table border="1">
        <thead>
            <th>placas</th>
            <th>descripcion</th>
            <th>precio</th>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($uno->placas); ?></td>
                <td><?php echo e($uno->descripcion); ?></td>
                <td><?php echo e($uno->precio); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="3">NO HAY CARROS</td>
        </tr>
        
        <?php endif; ?>
        </tbody>
    </table>

    si quieres agregar has click <a href="<?php echo e(route('carros-nuevo')); ?>">aqui</a>
</body>
</html><?php /**PATH /home/vagrant/code/laravel-10.x/resources/views/carro/listar.blade.php ENDPATH**/ ?>