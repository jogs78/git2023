<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<?php echo e(auth()->user()->nombre_completo); ?> (  <?php echo e(auth()->user()->tipo_de_usuario); ?> )
<a href="<?php echo e(route('terrenos.index')); ?>">LISTAR TERRENOS</a>  
<a href="<?php echo e(route('salir')); ?>">SALIR</a>  
<hr>
<body>
    <?php if(auth()->guard()->check()): ?>
    LISTAR LAS CASAS
    <table border="1">
        <thead>
            <th>Direccion</th>
            <th>Codigo Postal</th>
            <th>Eliminar</th>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $todas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $una): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('casas.show', $una->id)); ?>">
                            <?php echo e($una->direccion); ?>

                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('casas.edit', $una->id)); ?>">
                            <?php echo e($una->codigo_postal); ?>

                        </a>
                    </td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $una)): ?>
                            <form action="<?php echo e(route('casas.destroy', $una->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" value="BORRAR">
                            </form>
                            
                        <?php endif; ?>




                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">NO HAY CASAS</td>
                </tr>            
            <?php endif; ?>
        </tbody>
    </table>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Casa::class)): ?>
        <a href="<?php echo e(route('casas.create')); ?>">AGREGAR</a>      
    <?php endif; ?>


    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrar')): ?>
        <button>IR AL PANEL DE ADMINISTRACION</button>    
    
    <?php endif; ?>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    PRIMERO DEBES INICIAR SESION
<?php endif; ?>

</body>
</html><?php /**PATH /home/vagrant/code/laravel-10.x/resources/views/casa/index.blade.php ENDPATH**/ ?>