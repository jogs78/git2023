<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
        <?php echo e(auth()->user()->nombre_completo); ?> (  <?php echo e(auth()->user()->tipo_de_usuario); ?> )
        <a href="<?php echo e(route('casas.index')); ?>">LISTAR CASAS</a>  
        <a href="<?php echo e(route('salir')); ?>">SALIR</a>     
<hr>

    <table border="1">
        <thead>
            <th>Numero de servicio</th>
            <th>Direccion</th>
            <th>borrar</th>

        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('terrenos.show',$uno->id)); ?>">
                        <?php echo e($uno->servicio); ?>

                    </a>
                </td>
                <td>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $uno)): ?>
                        <a href="<?php echo e(route('terrenos.edit',$uno->id)); ?>">
                            <?php echo e($uno->direccion); ?>

                        </a>
                    <?php else: ?>
                        NO PUEDE EDITAR SOLO MOSTAR 
                    <?php endif; ?>

                </td>

                <td>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $uno)): ?>
                        <form action="<?php echo e(route('terrenos.destroy',$uno->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="X">
                        </form>
                    <?php endif; ?>

                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="3">NO HAY TERRENOS</td>
        </tr>
        
        <?php endif; ?>
        </tbody>
    </table>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Terreno::class)): ?>
        si quieres agregar has click <a href="<?php echo e(route('terrenos.create')); ?>">aqui</a>        
    <?php endif; ?>

</body>
</html><?php /**PATH /home/vagrant/code/laravel-10.x/resources/views/terreno/listar.blade.php ENDPATH**/ ?>