<?php

namespace App\Policies;

use App\Models\Usuario;

class TerrenoPolicy
{
    /**
     * Create a new policy instance.
     */
    public function __construct()
    {
        //
    }
}
